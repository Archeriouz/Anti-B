echo -ne "[\e[93m+\e[0m] Unistalling, Are you \e[93mSure?\e[0m [N/y] "; read Choice

if [ "${Choice}" == "Y" ] || [ "${Choice}" == "y" ]
then
sudo rm -rf ../Anti-B
else
exit
fi
