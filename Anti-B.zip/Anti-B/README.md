#----(Welcome)----#

This is the Easiest Stack of Sqlmap & ADF. , You can Use for Free [Now]! , Just go to Main, And Open Termux, Then type Bash antib.sh.

#----(Commands)----#
[![Runs Only Using Root!]($ sudo su)
- `help` for more Info.
- `clear` to clear the Window.
- `x` for Exit.
- [go] to SQL Injaction [Hack].

#----(Unistall)----#
- [1] : Go to Unistall.sh
- [2] : Open termux, Run Command.

#----$ bash Unistall.sh

Unistalls.

#----(Copyright)----#

Author: `Archer`

Powered by `Sqlmap`

ADF.pl Created by `Amr badawy` : [![Copyright](https://www.github.com/engtekno/AdminFinder)](Source Code)

[![Telegram](https://t.me/joinchat/df92LySfSz4xN2Ji)

[![Github](https://www.github.com/Archeriouz/Anti-B)

All rights Reserved. (C) 2021. Sqlmap Injection [![Sqlmap](https://www.sqlmap.org)

#----(End)----#
